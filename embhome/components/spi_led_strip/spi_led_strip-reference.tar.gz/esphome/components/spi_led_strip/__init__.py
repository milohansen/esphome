CODEOWNERS = ["@clydebarrow"]
DEPENDENCIES = ["spi"]
