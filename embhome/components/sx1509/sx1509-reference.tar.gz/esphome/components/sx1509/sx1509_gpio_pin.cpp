#include "esphome/core/helpers.h"
#include "esphome/core/log.h"
#include "sx1509.h"
#include "sx1509_gpio_pin.h"

namespace esphome {
namespace sx1509 {

static const char *const TAG = "sx1509_gpio_pin";

void SX1509GPIOPin::setup() { pin_mode(flags_); }
void SX1509GPIOPin::pin_mode(gpio::Flags flags) { this->parent_->pin_mode(this->pin_, flags); }
bool SX1509GPIOPin::digital_read() { return this->parent_->digital_read(this->pin_) != this->inverted_; }
void SX1509GPIOPin::digital_write(bool value) { this->parent_->digital_write(this->pin_, value != this->inverted_); }
size_t SX1509GPIOPin::dump_summary(char *buffer, size_t len) const {
  return buf_append_printf(buffer, len, 0, "%u via sx1509", this->pin_);
}

}  // namespace sx1509
}  // namespace esphome
