---
description: "Instructions for setting up water heaters in ESPHome."
title: "Water Heater Component"
---

The `water_heater` component is a generic representation of water heaters (boilers) in ESPHome. A water heater handles a target temperature setpoint and an operation mode (like *Eco*, *Electric*, or *Performance*).

> [!NOTE]
> Home Assistant integration for water heater entities is not yet available. See [home-assistant/core#159201](https://github.com/home-assistant/core/pull/159201) for progress.

{{< anchor "config-water-heater" >}}

## Base Water Heater Configuration

All water heater config schemas inherit from this schema - you can set these keys for water heaters.

```yaml
water_heater:
  - platform: ...
```

Configuration variables:

- **id** (*Optional*, string): Manually specify the ID for code generation. At least one of **id** and **name** must be specified.
- **name** (*Optional*, string): The name for the water heater. At least one of **id** and **name** must be specified.

> [!NOTE]
> If you have a [friendly_name](/components/esphome#esphome-configuration_variables) set for your device and you want the water heater
> to use that name, you can set `name: None`.

- **icon** (*Optional*, icon): Manually set the icon to use for the water heater in the frontend.

Advanced options:

- **visual** (*Optional*): Configuration for the frontend representation.
  - **min_temperature** (*Optional*, float): Override the minimum temperature shown in the frontend.
  - **max_temperature** (*Optional*, float): Override the maximum temperature shown in the frontend.
  - **target_temperature_step** (*Optional*, float): Override the temperature steps shown in the frontend.

- **supported_modes** (*Optional*, list): Static list of operation modes that will be exposed to the frontend (for example Home Assistant). When not specified, all modes supported by the platform are exposed.

  > **Note**
  > This option is platform-dependent. Not all water heater platforms allow configuring supported modes.

- **internal** (*Optional*, boolean): Mark this component as internal. Internal components will not be exposed to the
  frontend (like Home Assistant). Only specifying an `id` without a `name` will implicitly set this to true.

- **disabled_by_default** (*Optional*, boolean): If true, this entity should not be added to any client's frontend,
  (usually Home Assistant) without the user manually enabling it (via the Home Assistant UI). Defaults to `false`.

- **entity_category** (*Optional*, string): The category of the entity. See
  <https://developers.home-assistant.io/docs/core/entity/#generic-properties> for a list of available options. Set to
  `""` to remove the default entity category.

- If Webserver enabled and version 3 is selected, All other options from Webserver Component.. See [Webserver Version 3](/components/web_server#config-webserver-version-3-options).

MQTT options:

- **mode_command_topic** (*Optional*, string): The topic to receive mode commands on.
- **mode_state_topic** (*Optional*, string): The topic to publish mode state changes to.
- **target_temperature_command_topic** (*Optional*, string): The topic to receive target temperature commands on.
- **target_temperature_state_topic** (*Optional*, string): The topic to publish target temperature state changes to.
- All other options from [MQTT Component](/components/mqtt#config-mqtt-component).

{{< anchor "water-heater-control_action" >}}

## `water_heater.control` Action

This [action](/automations/actions#all-actions) allows you to set the operation mode and/or target temperature of the water heater.

```yaml
on_...:
  then:
    - water_heater.control:
        id: boiler_1
        mode: ECO
        target_temperature: 55.0
```

Configuration variables:

- **id** (**Required**, [ID](/guides/configuration-types#id)): The water heater to control.
- **mode** (*Optional*, string): The operation mode to set. See [Modes](#water-heater-modes) for available options.
- **target_temperature** (*Optional*, float): The target temperature to set _commlable options. Set to
*
  > Ttemperature to set _commenabled and version 3 is selected, All other  to
*
  > Tform are tnd t to
*
  > Ttemperatu_eguration-types#ident operation mode. Expects a `WaterHeaterMode`# See Also

- {on m heat =toma**Requir).maket_eat< apir_eatompong. `4"PERFORMANCE" apir_eatompon  > Ttemperature t(6}
- [Aut_eatodiately< apiref "ttions/actions#all-actions set o set the n can also be writater hfo the The startup. able optio*Optional*, stringan):or the w): Marknt as intetempts t Not all  [Web`OFF`Web`lateWeb`lLECTRICeWeb`PERFORMANCEeWeb`HIGH_DEMANDeWeb`HEAT_PUMPeWeb`GAS "ttions/actions#all-actionserModet_eat o set the  returtatFn" >}nt operation mode. Expects a `WaterHeaterMode`r heater iacc-tynal*, boolean/compon mode: ECO
        ta(e.g. `water_heater::WA riablhe from Weions/templates), float):
  Thn mode: ECO
 (ed and targeo

-**id*f (omation](/autog. `water_heater::W < 4 > ) {/config// n can ant).ld/conf}ter he(e.  > Ttemperature tA riablhe from We, string):
  The operation m(ed and taation va riablhe from Weions/tem): Whether to otargeo

-**id*f (omation](/autonal*,==ptional)
    supported_modes:
      ) {/config// ent_te antElecCOr to /conf}on
- d*f (omation](/autonal*,==ptional)
    supported_modes:
   PERFORMANCE) {/config// ent_te antElePERFORMANCEr to /conf}ter heAble optioC++: Do  (*Optrature:aatitional)
    supported_modes:
   OFF`Web`nal*, [lambda](/automations/templateWeb`nal*, [lambda](/automations/templLECTRICeWeb`tional)
    supported_modes:
   PERFORMANCEeWeb`tional)
    supported_modes:
   HIGH_DEMANDeWeb`tional)
    supported_modes:
   HEAT_PUMPeWeb`tional)
    supported_modes:
   GAS "template/water_heater/template_water_heater