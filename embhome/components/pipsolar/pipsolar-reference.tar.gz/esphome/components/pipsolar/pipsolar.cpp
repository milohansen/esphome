#include "pipsolar.h"
#include "esphome/core/helpers.h"
#include "esphome/core/log.h"

namespace esphome {
namespace pipsolar {

static const char *const TAG = "pipsolar";

void Pipsolar::setup() {
  this->state_ = STATE_IDLE;
  this->command_start_millis_ = 0;
}

void Pipsolar::empty_uart_buffer_() {
  uint8_t byte;
  while (this->available()) {
    this->read_byte(&byte);
  }
}

void Pipsolar::loop() {
  // Read message
  if (this->state_ == STATE_IDLE) {
    this->empty_uart_buffer_();

    if (this->send_next_command_()) {
      // command sent
      return;
    }

    if (this->send_next_poll_()) {
      // poll sent
      return;
    }

    return;
  }
  if (this->state_ == STATE_COMMAND_COMPLETE) {
    if (this->check_incoming_length_(4)) {
      if (this->check_incoming_crc_()) {
        // crc ok
        if (this->read_buffer_[1] == 'A' && this->read_buffer_[2] == 'C' && this->read_buffer_[3] == 'K') {
          ESP_LOGD(TAG, "command successful");
        } else {
          ESP_LOGD(TAG, "command not successful");
        }
        this->command_queue_[this->command_queue_position_] = std::string("");
        this->command_queue_position_ = (command_queue_position_ + 1) % COMMAND_QUEUE_LENGTH;
        this->state_ = STATE_IDLE;
      } else {
        // crc failed
        // no log message necessary, check_incoming_crc_() logs
        this->command_queue_[this->command_queue_position_] = std::string("");
        this->command_queue_position_ = (command_queue_position_ + 1) % COMMAND_QUEUE_LENGTH;
        this->state_ = STATE_IDLE;
      }
    } else {
      ESP_LOGD(TAG, "command %s response length not OK: with length %zu",
               this->command_queue_[this->command_queue_position_].c_str(), this->read_pos_);
      this->command_queue_[this->command_queue_position_] = std::string("");
      this->command_queue_position_ = (command_queue_position_ + 1) % COMMAND_QUEUE_LENGTH;
      this->state_ = STATE_IDLE;
    }
  }

  if (this->state_ == STATE_POLL_CHECKED) {
    ESP_LOGD(TAG, "poll %s decode", this->enabled_polling_commands_[this->last_polling_command_].command);
    this->handle_poll_response_(this->enabled_polling_commands_[this->last_polling_command_].identifier,
                                (const char *) this->read_buffer_);
    this->state_ = STATE_IDLE;
    return;
  }

  if (this->state_ == STATE_POLL_COMPLETE) {
    if (this->check_incoming_crc_()) {
      if (this->read_buffer_[0] == '(' && this->read_buffer_[1] == 'N' && this->read_buffer_[2] == 'A' &&
          this->read_buffer_[3] == 'K') {
        ESP_LOGD(TAG, "poll %s NACK", this->enabled_polling_commands_[this->last_polling_command_].command);
        this->handle_poll_error_(this->enabled_polling_commands_[this->last_polling_command_].identifier);
        this->state_ = STATE_IDLE;
        return;
      }
      // crc ok
      this->enabled_polling_commands_[this->last_polling_command_].needs_update = false;
      this->state_ = STATE_POLL_CHECKED;
      return;
    } else {
      // crc failed
      // no log message necessary, check_incoming_crc_() logs
      this->handle_poll_error_(this->enabled_polling_commands_[this->last_polling_command_].identifier);
      this->state_ = STATE_IDLE;
    }
  }

  if (this->state_ == STATE_COMMAND || this->state_ == STATE_POLL) {
    while (this->available()) {
      uint8_t byte;
      this->read_byte(&byte);

      // make sure data and null terminator fit in buffer
      if (this->read_pos_ >= PIPSOLAR_READ_BUFFER_LENGTH - 1) {
        this->read_pos_ = 0;
        this->empty_uart_buffer_();
        ESP_LOGW(TAG, "response data too long, discarding.");
        break;
      }
      this->read_buffer_[this->read_pos_] = byte;
      this->read_pos_++;

      // end of answer
      if (byte == 0x0D) {
        this->read_buffer_[this->read_pos_] = 0;
        this->empty_uart_buffer_();
        if (this->state_ == STATE_POLL) {
          this->state_ = STATE_POLL_COMPLETE;
        }
        if (this->state_ == STATE_COMMAND) {
          this->state_ = STATE_COMMAND_COMPLETE;
        }
      }
    }  // available
  }
  if (this->state_ == STATE_COMMAND) {
    if (millis() - this->command_start_millis_ > esphome::pipsolar::Pipsolar::COMMAND_TIMEOUT) {
      // command timeout
      const char *command = this->command_queue_[this->command_queue_position_].c_str();
      this->command_start_millis_ = millis();
      ESP_LOGD(TAG, "command %s timeout", command);
      this->command_queue_[this->command_queue_position_] = std::string("");
      this->command_queue_position_ = (command_queue_position_ + 1) % COMMAND_QUEUE_LENGTH;
      this->state_ = STATE_IDLE;
      return;
    }
  }
  if (this->state_ == STATE_POLL) {
    if (millis() - this->command_start_millis_ > esphome::pipsolar::Pipsolar::COMMAND_TIMEOUT) {
      // command timeout
      ESP_LOGD(TAG, "poll %s timeout", this->enabled_polling_commands_[this->last_polling_command_].command);
      this->handle_poll_error_(this->enabled_polling_commands_[this->last_polling_command_].identifier);
      this->state_ = STATE_IDLE;
    }
  }
}

uint8_t Pipsolar::check_incoming_length_(uint8_t length) {
  if (this->read_pos_ - 3 == length) {
    return 1;
  }
  return 0;
}

uint8_t Pipsolar::check_incoming_crc_() {
  uint16_t crc16;
  crc16 = this->pipsolar_crc_(read_buffer_, read_pos_ - 3);
  if (((uint8_t) ((crc16) >> 8)) == read_buffer_[read_pos_ - 3] &&
      ((uint8_t) ((crc16) &0xff)) == read_buffer_[read_pos_ - 2]) {
    ESP_LOGD(TAG, "CRC OK");
    read_buffer_[read_pos_ - 1] = 0;
    read_buffer_[read_pos_ - 2] = 0;
    read_buffer_[read_pos_ - 3] = 0;
    return 1;
  }
  ESP_LOGD(TAG, "CRC NOK expected: %X %X but got: %X %X", ((uint8_t) ((crc16) >> 8)), ((uint8_t) ((crc16) &0xff)),
           read_buffer_[read_pos_ - 3], read_buffer_[read_pos_ - 2]);
  return 0;
}

// send next command from queue
bool Pipsolar::send_next_command_() {
  uint16_t crc16;
  if (!this->command_queue_[this->command_queue_position_].empty()) {
    const char *command = this->command_queue_[this->command_queue_position_].c_str();
    uint8_t byte_command[16];
    uint8_t length = this->command_queue_[this->command_queue_position_].length();
    for (uint8_t i = 0; i < length; i++) {
      byte_command[i] = (uint8_t) this->command_queue_[this->command_queue_position_].at(i);
    }
    this->state_ = STATE_COMMAND;
    this->command_start_millis_ = millis();
    this->empty_uart_buffer_();
    this->read_pos_ = 0;
    crc16 = this->pipsolar_crc_(byte_command, length);
    this->write_str(command);
    // checksum
    this->write(((uint8_t) ((crc16) >> 8)));   // highbyte
    this->write(((uint8_t) ((crc16) &0xff)));  // lowbyte
    // end Byte
    this->write(0x0D);
    ESP_LOGD(TAG, "Sending command from queue: %s with length %d", command, length);
    return true;
  }
  return false;
}

bool Pipsolar::send_next_poll_() {
  uint16_t crc16;
  for (uint8_t i = 0; i < POLLING_COMMANDS_MAX; i++) {
    this->last_polling_command_ = (this->last_polling_command_ + 1) % POLLING_COMMANDS_MAX;
    if (this->enabled_polling_commands_[this->last_polling_command_].length == 0) {
      // not enabled
      continue;
    }
    if (!this->enabled_polling_commands_[this->last_polling_command_].needs_update) {
      // no update requested
      continue;
    }
    this->state_ = STATE_POLL;
    this->command_start_millis_ = millis();
    this->empty_uart_buffer_();
    this->read_pos_ = 0;
    crc16 = this->pipsolar_crc_(this->enabled_polling_commands_[this->last_polling_command_].command,
                                this->enabled_polling_commands_[this->last_polling_command_].length);
    this->write_array(this->enabled_polling_commands_[this->last_polling_command_].command,
                      this->enabled_polling_commands_[this->last_polling_command_].length);
    // checksum
    this->write(((uint8_t) ((crc16) >> 8)));   // highbyte
    this->write(((uint8_t) ((crc16) &0xff)));  // lowbyte
    // end Byte
    this->write(0x0D);
    ESP_LOGD(TAG, "Sending polling command: %s with length %d",
             this->enabled_polling_commands_[this->last_polling_command_].command,
             this->enabled_polling_commands_[this->last_polling_command_].length);
    return true;
  }
  return false;
}

void Pipsolar::queue_command(const std::string &command) {
  uint8_t next_position = command_queue_position_;
  for (uint8_t i = 0; i < COMMAND_QUEUE_LENGTH; i++) {
    uint8_t testposition = (next_position + i) % COMMAND_QUEUE_LENGTH;
    if (command_queue_[testposition].empty()) {
      command_queue_[testposition] = command;
      ESP_LOGD(TAG, "Command queued successfully: %s at position %d", command.c_str(), testposition);
      return;
    }
  }
  ESP_LOGD(TAG, "Command queue full dropping command: %s", command.c_str());
}

void Pipsolar::handle_poll_response_(ENUMPollingCommand polling_command, const char *message) {
  switch (polling_command) {
    case POLLING_QPIRI:
      handle_qpiri_(message);
      break;
    case POLLING_QPIGS:
      handle_qpigs_(message);
      break;
    case POLLING_QMOD:
      handle_qmod_(message);
      break;
    case POLLING_QFLAG:
      handle_qflag_(message);
      break;
    case POLLING_QPIWS:
      handle_qpiws_(message);
      break;
    case POLLING_QT:
      handle_qt_(message);
      break;
    case POLLING_QMN:
      handle_qmn_(message);
      break;
    default:
      break;
  }
}
void Pipsolar::handle_poll_error_(ENUMPollingCommand polling_command) {
  // handlers are designed in a way that an empty message sets all sensors to unknown
  this->handle_poll_response_(polling_command, "");
}

void Pipsolar::handle_qpiri_(const char *message) {
  if (this->last_qpiri_) {
    this->last_qpiri_->publish_state(message);
  }

  size_t pos = 0;
  this->skip_start_(message, &pos);

  this->read_float_sensor_(message, &pos, this->grid_rating_voltage_);
  this->read_float_sensor_(message, &pos, this->grid_rating_current_);
  this->read_float_sensor_(message, &pos, this->ac_output_rating_voltage_);
  this->read_float_sensor_(message, &pos, this->ac_output_rating_frequency_);
  this->read_float_sensor_(message, &pos, this->ac_output_rating_current_);

  this->read_int_sensor_(message, &pos, this->ac_output_rating_apparent_power_);
  this->read_int_sensor_(message, &pos, this->ac_output_rating_active_power_);

  this->read_float_sensor_(message, &pos, this->battery_rating_voltage_);
  this->read_float_sensor_(message, &pos, this->battery_recharge_voltage_);
  this->read_float_sensor_(message, &pos, this->battery_under_voltage_);
  this->read_float_sensor_(message, &pos, this->battery_bulk_voltage_);
  this->read_float_sensor_(message, &pos, this->battery_float_voltage_);

  this->read_int_sensor_(message, &pos, this->battery_type_);
  this->read_int_sensor_(message, &pos, this->current_max_ac_charging_current_);
  this->read_int_sensor_(message, &pos, this->current_max_charging_current_);

  esphome::optional<int> input_voltage_range = parse_number<int32_t>(this->read_field_(message, &pos));
  esphome::optional<int> output_source_priority = parse_number<int32_t>(this->read_field_(message, &pos));

  this->read_int_sensor_(message, &pos, this->charger_source_priority_);
  this->read_int_sensor_(message, &pos, this->parallel_max_num_);
  this->read_int_sensor_(message, &pos, this->machine_type_);
  this->read_int_sensor_(message, &pos, this->topology_);
  this->read_int_sensor_(message, &pos, this->output_mode_);

  this->read_float_sensor_(message, &pos, this->battery_redischarge_voltage_);

  esphome::optional<int> pv_ok_condition_for_parallel = parse_number<int32_t>(this->read_field_(message, &pos));
  esphome::optional<int> pv_power_balance = parse_number<int32_t>(this->read_field_(message, &pos));

  if (this->input_voltage_range_) {
    this->input_voltage_range_->publish_state(input_voltage_range.value_or(NAN));
  }
  // special for input voltage range switch
  if (this->input_voltage_range_switch_ && input_voltage_range.has_value()) {
    this->input_voltage_range_switch_->publish_state(input_voltage_range.value() == 1);
  }

  if (this->output_source_priority_) {
    this->output_source_priority_->publish_state(output_source_priority.value_or(NAN));
  }
  // special for output source priority switches
  if (this->output_source_priority_utility_switch_ && output_source_priority.has_value()) {
    this->output_source_priority_utility_switch_->publish_state(output_source_priority.value() == 0);
  }
  if (this->output_source_priority_solar_switch_ && output_source_priority.has_value()) {
    this->output_source_priority_solar_switch_->publish_state(output_source_priority.value() == 1);
  }
  if (this->output_source_priority_battery_switch_ && output_source_priority.has_value()) {
    this->output_source_priority_battery_switch_->publish_state(output_source_priority.value() == 2);
  }
  if (this->output_source_priority_hybrid_switch_ && output_source_priority.has_value()) {
    this->output_source_priority_hybrid_switch_->publish_state(output_source_priority.value() == 3);
  }

  if (this->pv_ok_condition_for_parallel_) {
    this->pv_ok_condition_for_parallel_->publish_state(pv_ok_condition_for_parallel.value_or(NAN));
  }
  // special for pv ok condition switch
  if (this->pv_ok_condition_for_parallel_switch_ && pv_ok_condition_for_parallel.has_value()) {
    this->pv_ok_condition_for_parallel_switch_->publish_state(pv_ok_condition_for_parallel.value() == 1);
  }

  if (this->pv_power_balance_) {
    this->pv_power_balance_->publish_state(pv_power_balance.value_or(NAN));
  }
  // special for power balance switch
  if (this->pv_power_balance_switch_ && pv_power_balance.has_value()) {
    this->pv_power_balance_switch_->publish_state(pv_power_balance.value() == 1);
  }
}

void Pipsolar::handle_qpigs_(const char *message) {
  if (this->last_qpigs_) {
    this->last_qpigs_->publish_state(message);
  }

  size_t pos = 0;
  this->skip_start_(message, &pos);

  this->read_float_sensor_(message, &pos, this->grid_voltage_);
  this->read_float_sensor_(message, &pos, this->grid_frequency_);
  this->read_float_sensor_(message, &pos, this->ac_output_voltage_);
  this->read_float_sensor_(message, &pos, this->ac_output_frequency_);

  this->read_int_sensor_(message, &pos, this->ac_output_apparent_power_);
  this->read_int_sensor_(message, &pos, this->ac_output_active_power_);
  this->read_int_sensor_(message, &pos, this->output_load_percent_);
  this->read_int_sensor_(message, &pos, this->bus_voltage_);

  this->read_float_sensor_(message, &pos, this->battery_voltage_);

  this->read_int_sensor_(message, &pos, this->battery_charging_current_);
  this->read_int_sensor_(message, &pos, this->battery_capacity_percent_);
  this->read_int_sensor_(message, &pos, this->inverter_heat_sink_temperature_);

  this->read_float_sensor_(message, &pos, this->pv_input_current_for_battery_);
  this->read_float_sensor_(message, &pos, this->pv_input_voltage_);
  this->read_float_sensor_(message, &pos, this->battery_voltage_scc_);

  this->read_int_sensor_(message, &pos, this->battery_discharge_current_);

  std::string device_status_1 = this->read_field_(message, &pos);
  this->publish_binary_sensor_(this->get_bit_(device_status_1, 0), this->add_sbu_priority_version_);
  this->publish_binary_sensor_(this->get_bit_(device_status_1, 1), this->configuration_status_);
  this->publish_binary_sensor_(this->get_bit_(device_status_1, 2), this->scc_firmware_version_);
  this->publish_binary_sensor_(this->get_bit_(device_status_1, 3), this->load_status_);
  this->publish_binary_sensor_(this->get_bit_(device_status_1, 4), this->battery_voltage_to_steady_while_charging_);
  this->publish_binary_sensor_(this->get_bit_(device_status_1, 5), this->charging_status_);
  this->publish_binary_sensor_(this->get_bit_(device_status_1, 6), this->scc_charging_status_);
  this->publish_binary_sensor_(this->get_bit_(device_status_1, 7), this->ac_charging_status_);

  esphome::optional<int> battery_voltage_offset_for_fans_on = parse_number<int32_t>(this->read_field_(message, &pos));
  if (this->battery_voltage_offset_for_fans_on_) {
    this->battery_voltage_offset_for_fans_on_->publish_state(battery_voltage_offset_for_fans_on.value_or(NAN) / 10.0f);
  }
  this->read_int_sensor_(message, &pos, this->eeprom_version_);
  this->read_int_sensor_(message, &pos, this->pv_charging_power_);

  std::string device_status_2 = this->read_field_(message, &pos);
  this->publish_binary_sensor_(this->get_bit_(device_status_2, 0), this->charging_to_floating_mode_);
  this->publish_binary_sensor_(this->get_bit_(device_status_2, 1), this->switch_on_);
  this->publish_binary_sensor_(this->get_bit_(device_status_2, 2), this->dustproof_installed_);
}

void Pipsolar::handle_qmod_(const char *message) {
  std::string mode;
  char device_mode = char(message[1]);
  if (this->last_qmod_) {
    this->last_qmod_->publish_state(message);
  }
  if (this->device_mode_) {
    mode = device_mode;
    this->device_mode_->publish_state(mode);
  }
}

void Pipsolar::handle_qflag_(const char *message) {
  // result like:"(EbkuvxzDajy"
  // get through all char: ignore first "(" Enable flag on 'E', Disable on 'D') else set the corresponding value
  if (this->last_qflag_) {
    this->last_qflag_->publish_state(message);
  }

  QFLAGValues values = QFLAGValues();
  bool enabled = true;
  for (size_t i = 1; i < strlespoish_binary_se1, 20>publisEPoish_binarzlues();
  -.)pdnalish_us_1, 2), this->scc_firmware_verzlues();D  -.)pdnalish_us_1, 2update = fals_firmware_verzlues();a  -.)pdnaliAGValu.lled
- **silence_buzzer_op, 2sh_us_1e = fals_firmware_verzlues();b  -.)pdnaliAGValu.zzer
- **overload_bypass, 2sh_us_1e = fals_firmware_verzlues();k  -.)pdnaliAGValu.tion
- **lcd_escape_t, 2sh_us_1e = fals_firmware_verzlues();u  -.)pdnaliAGValu.zzer
- **perature_restart, 2sh_us_1e = fals_firmware_verzlues();v  -.)pdnaliAGValu.zzer
- **over_temperature_restart, 2sh_us_1e = fals_firmware_verzlues();x  -.)pdnaliAGValu.tion
- **bac, 2sh_us_1e = fals_firmware_verzlues();y  -.)pdnaliAGValu.t on
- **alarm_on_when_primary_source_, 2sh_us_1e = fals_firmware_verzlues();z  -.)pdnaliAGValu.rupt
- **fault_co, 2sh_us_1e = fals_firmware_verzlues();j  -.)pdnaliAGValu.cord
- **pow, 2sh_us_1e = fals_firmware_verDLE;
    _on_);
  this->publish_binaryAGValu.lled
- **silence_buzzer_optus_2, 1)led
- **silence_buzzer_opswitch_on_);
  this->publish_binaryAGValu.zzer
- **overload_bypassage, &poszer
- **overload_bypassswitch_on_);
  this->publish_binaryAGValu.tion
- **lcd_escape_ttus_1, 3)ion
- **lcd_escape_tswitch_on_);
  this->publish_binaryAGValu.zzer
- **perature_restartage, &poszer
- **perature_restartswitch_on_);
  this->publish_binaryAGValu.zzer
- **over_temperature_restartage, &poszer
- **over_temperature_restartswitch_on_);
  this->publish_binaryAGValu.tion
- **bactus_1, 4),on
- **bacswitch_on_);
  this->publish_binaryAGValu.t on
- **alarm_on_when_primary_source_].command,
                      s_1, 7) on
- **alarm_on_when_primary_source_switch_on_);
  this->publish_binaryAGValu.rupt
- **fault_cotus_1, 4rupt
- **fault_coswitch_on_);
  this->publish_binaryAGValu.cord
- **powage, &posord
- **powinstalled_);
}

void Pipsolar: handle_qflag_(const char *message'(00000000000000000000000000000000'essageitoverdc volt thr   }  // (" Ena(as
     thrsh_sls have  thr" Ensagd: %a   uonalin elsesamdc rder)essage) {
  if (this-wlast_qpigs_) {
    this-wlast_qpigs_->publish_state(message);
  }

  size_t pos = 0;
  this->skip_start_(messagessage) {
  std" Ens_status_2 = this->read_field_(messagetatus_);

  esphome::ues(>2sh_us_1e = ues()_fans_ing

- **warning, 2update = ues()_fans_sent
- **fault, 2update d = true;
  for (sit8_t i 36poish_binary_age)iy.val1E_COiy.val2ds_update) {
  }
  //ues()e offsnal*): fa_verzlud
      continue;
 sh_us_1, 2)sensor_(this->" Ensagion_].atse1, 20>ish_binarzlues()0 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &posent
- **warning_p>read_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()1 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
- **fault_inver>read_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()2 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
- **fault>read_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()3 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
- **f>batteread_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()4 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
- **finverter_eread_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()5 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &posent
- **warning_>read_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()6 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
-): faulteread_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()7 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
- **fault_inverter_voltageread_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()8 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
- **fault_inverter_vol*warnread_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()9 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &posent
- *szer
- **over_temread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()10 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &posent
- **warningmread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()11 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &polock
- **warning_battery_volmread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()12 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &pohigh
- **warning_battery_mread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()14 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &polarm
- **warning_battery_undermread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()15 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &posent
- **warning_batterymread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()16 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poting
- **warning_mread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()17 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poload
- **warning_eeprmread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()18 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
- **fault_lt_dc_dc_ovenread_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()19 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &porent
- **fault_inverter_so>read_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()20 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poional*): fault_self_te>read_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()21 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
- **fault_op_dc_vol>read_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()22 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
- **fault_bat>read_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()23 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
- **fault_current_sens>read_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()24 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
- **fault_batt>read_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()25 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &posent
- **warning_pomread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()26 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poting
- **warning_pv_volmread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()27 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poloss
-*warning_mppt>read_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()28 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poload
- **warning_mpptmread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()29 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &posent
- **warning_battery_too_low_mread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()30 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &poional* **fault_dc_dc_ove>read_pos_ )_fans_sent
- **fault,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()33 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &pocode
- **warning_low_mread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        breaues()34 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &polarm
- **warning_high_ac_input_during_bus_smread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding."ues()35 -.)pdnali_on_);
  this->publish_binarysh_us_1age, &posent
- **warning battery equmread_pos_ )_fans_ing

- **warning,| 2sh_us_1r_fans_on.updatcarding.");
        brDLE;
    _on_);
  this->publish_binaryAGVal_ing

- **warningage, &posent
- **warningswitch_on_);
  this->publish_binaryAGVal_sent
- **faultage, &poional**warningswit
ssage) {
  irupt
- **fa_binary_age)" Ensosition_] i 33sh_binarzl {
  irupt
- **fast_qpigs_->publivalu    brDrn;
    } elseage) {
  std"c>" Ensag3e_sta;binarzl {
  irupt
- **fast_qpigs_->publians_on = parse_n>(fc)r_balance.value_or(_IDLE;
    ed_);
}

void Pipsolar:tdle_qpigs_(const char *message) {
  if (thitast_qpigs_) {
    thitast_qpigs_->publish_state(messaalled_);
}

void Pipsolar::ndle_qpigs_(const char *message) {
  if (thimor_fans_on_) {
 f (thimorst_qpigs_->publish_state(messaalled_);
}

void P
  this->skie_qpigs_(const char,);
  }

e;

 *message)publisEPe;

buffer_[_fans_on(e;

 read  break;
  }
}
void P
  this->reae_qpigs_(const char,);
  }

e;

 *mess// find deng_poeromat      /{
  st
OLL) {
  publisEPe;

bu!fer\0[1] =publisEPe;

bu!fer [_fans_on(e;

 read  brssage)publisEPe;

bu!fer\0[_fans_on {
   t deng_poeroafoero_) { is->rsagethere  { onens_on(e;

 read  breaage) {
  std}
}
void P = this->reae_qpigs_(const char,);
  }

e;

 *mess;
  }

begic, 2e;

;ess// find deng_poeromat      /{
  st
OLL) {
  publisEPe;

bu!fer\0[1] =publisEPe;

bu!fer [_fans_on(e;

 read  brssage)*  siz=
begic== length) {
  "";LE;
    age) {
  std"s->rad_field_(begic,2e;

 -
begic=it
ssage)publisEPe;

bu!fer\0[_fans_on {
   t deng_poeroafoero_) { is->rsagethere  { onens_on(e;

 read  br
rue;
  }
 s->rstalled_);
}

void P
  this->read_floate_qpigs_(const char,);
  }

e;

, sets a::Sll tex*sets a *message)sets au!fedataptr_binary_sge) {
  std"s->r_status_2 = this->read_field_(essagess  sets ast_qpigs_->publians_on = parsis->r>(fs->r)r_balance.value_or(Drn;
    } els = 0;
  this->read_field_(essagessbreak;
  }
}
void P
  this->read_inte_qpigs_(const char,);
  }

e;

, sets a::Sll tex*sets a *message)sets au!fedataptr_binary_sge) {
  std"s->r_status_2 = this->read_field_(essagess  us_);

  esphome::optumberfans_odr_fans_on = parse_number<fs->r)gess  sets ast_qpigs_->publians_odr_balance.ha ?fans_odr_balance: valu    Drn;
    } els = 0;
  this->read_field_(essagessbreaak;
  }
}
void P
  this->publish_binaryss_);

  esphome::ues(>2b_(bpublish_bina::BpubliSll tex*sets a *message)sets a_binary_age)br_balance.has_value(  sets ast_qpigs_->publibr_balancu    brDrn;
    } elseaets astin_bai // ->publie_or(_IDLE;
    ss_);

  esphome::ues(>2}
}
void Pr_(this->sge) {
  stdhis
, r();
    ion =  *message) ion = readhis
osition_]== length) {
  {}ad  brssh) {
  his
[ ion = buffer1'stalled_);
}

void Pdump_), thiext_pol }
  }
CONFIG ESP_LO
}

void \n"rding.");;;;;;;;;;;;;;"sh_us_1,"Sending pollins:, "CRC trueatab &   this->enabled_polline: e, &pos  this->enabled_polling__binary_age)s  this->enabled_pollincommand_!.length == 0) }
  }
CONFIG ESP_LOcommas  this->enabled_pollincrite_str(comma}essbreak;
  }
}
void P   // ext_pol trueatab &   this->enabled_polline: e, &pos  this->enabled_polling__binary_age)s  this->enabled_pollincommand_!.length == 0)s  this->enabled_pollincommand_].needs_), this->sDLE;
    ed_);
}

void P), tis->last_polling()) {
    const char, l_error_(ENUMPollingCommand polling_comm trueatab &   this->enabled_polline: e, &pos  this->enabled_polling__binary_age)s  this->enabled_pollincommand_== = 1; i  pollingailable()) {
     ; i = = 1; i  polling;binarzlage)pumcmp)s  this->enabled_pollinc polling_coh %d", com)_].length == 0)E;
        return;
   }nary_age)s  this->enabled_pollincommand_== ength == 0);
  }

 uint8_t = 1; i  polling;bh == 0)s  this->enabled_pollincst char *cnew) {
    [ uint8_+ 1] &0xffNOLINT(cpp"esp*, [I*wars-owt
- -pumory)h == 0) true;
  for (sit8_t i  uint8_+ 1 < length; i++)0)s  this->enabled_pollincst chare_command[i] = (st chare_c   return;
   0)s  this->enabled_pollincdle_psize_t po  0)s  this->enabled_pollincommand_].ir_faenabled_pollint po  0)s  this->enabled_pollinc uint8_t = 0; i h == 0)s  this->enabled_pollincommand_].needs_), this->son);
      return;
 eturn 0 {
  }
}
void P
= this->pipso {
     *msg,) {
     ; ixt_poll_() {
  uinvicet8_tblissg,); ix;
)) {
     pipslowvicet8 & (crc;
)) {
     pips*warvicet8 ((cr;essage)pipslowvif (b28E_COpipslowvif (b0dE_COpipslowvif (b0a)h == pipslowread  age)pips*warvif (b28E_COpips*warvif (b0dE_COpips*warvif (b0a)h == pips*warread  uinvic)pips*warv<< 8) COpipslow;rssh) {
  pipstall   }
 sphome {
namespacel   }
 sphome {
nss_);

nts/uart)
