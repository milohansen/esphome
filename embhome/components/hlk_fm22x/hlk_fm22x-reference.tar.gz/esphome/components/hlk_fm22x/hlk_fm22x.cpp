#include "hlk_fm22x.h"
#include "esphome/core/log.h"
#include "esphome/core/helpers.h"
#include <array>
#include <cinttypes>

namespace esphome::hlk_fm22x {

static const char *const TAG = "hlk_fm22x";

// Maximum response size is 36 bytes (VERIFY reply: face_id + 32-byte name)
static constexpr size_t HLK_FM22X_MAX_RESPONSE_SIZE = 36;

void HlkFm22xComponent::setup() {
  ESP_LOGCONFIG(TAG, "Setting up HLK-FM22X...");
  this->set_enrolling_(false);
  while (this->available()) {
    this->read();
  }
  this->defer([this]() { this->send_command_(HlkFm22xCommand::GET_STATUS); });
}

void HlkFm22xComponent::update() {
  if (this->active_command_ != HlkFm22xCommand::NONE) {
    if (this->wait_cycles_ > 600) {
      ESP_LOGE(TAG, "Command 0x%.2X timed out", this->active_command_);
      if (HlkFm22xCommand::RESET == this->active_command_) {
        this->mark_failed();
      } else {
        this->reset();
      }
    }
  }
  this->recv_command_();
}

void HlkFm22xComponent::enroll_face(const std::string &name, HlkFm22xFaceDirection direction) {
  if (name.length() > 31) {
    ESP_LOGE(TAG, "enroll_face(): name too long '%s'", name.c_str());
    return;
  }
  ESP_LOGI(TAG, "Starting enrollment for %s", name.c_str());
  std::array<uint8_t, 35> data{};
  data[0] = 0;  // admin
  std::copy(name.begin(), name.end(), data.begin() + 1);
  // Remaining bytes are already zero-initialized
  data[33] = (uint8_t) direction;
  data[34] = 10;  // timeoutnst char *cr ESPr *crOLLme.begi.begname.begiame)nt for  up HLK-FM22X...");
 true  this->recv_command_();
}

vosphomESP_LOm22xComponen return;Verl*,  stat for %sphome::hlk_ialized DATA[) di{0, 0};[34] = 10;  // timeoutnst char *cr ESPr nse si, DATA,name)of(DATA)  this->recv_command_();
}

voen:
   ESP_Lali16ed mbda |-
     omponen return;Dn:
 in()ht`, `bont, t%dtinto slot "   ::hlk_ialized uint8) di{tialized
 nto slot >> 8ametialized
 nto slot &ESPFF)};[34] = 10;  // timeoutnst char *cr ESPr DELETE_FACEme.beg,name)of(.beg)  this->recv_command_();
}

voen:
   a   ESP_sLOm22xComponen return;Dn:
 in()_allber of ESP_setting up HLK- // timeoutnst char *cr ESPr DELETE_ALL_FACES  this->recv_command_();
}

vogeensor/i

## _LOm22xComponenDreturn;G ESP_LOht`, 

## etting up HLK- // timeoutnst char *cr ESPr and_ALL_FACE_IDS  this->recv_command_();
}

vo else {m22xComponen return;_fm22SP_LOails ietting up HLpdate() {
  if (his->active_command_ !=ting up HLNONE) {
    i35> ing up HLK-FM22X...");
  this->set up HLK- // timeoutnst char *cr ESPr  if (  this->recv_command_();
}

vos- // timeoutnst char *cr ESPing corr, ::hlk_ialized *.beg,name)ed ame){m22xComponenVup() {
  SPing corr:ESP_LOG",ing corr->setmponent::update() {
  if (this->active_command_ != HlkFm22omponenW 600) {
      ESP_LOGE/ Remainpdate(mmand 0x%.2X timed out", this->", name.c_str( up HLNONE) {
    i35> ing up HLpdate() {
  if (hi {
  if>set_enrolling_(false);
  whi (this->available())  up HLNatio(tialized
 n(HlRT_CODE >> 8ae())  up HLNatio(tialized
 n(HlRT_CODE &ESPFF)e())  up HLNatio(tialized
 ng corr->setuali16ed .beg_

// = ame)())  up HLNatio(tialized
 n.beg_

// >> 8ae())  up HLNatio(tialized
 n.beg_

// &ESPFF)e()setualized checks"hl35> ingchecks"hl^nitialized
  {
  if>setchecks"hl^nit.beg_

// >> 8a>setchecks"hl^nit.beg_

// &ESPFF)>set "St(ame)ed i 35> di < ame)( i++ile (this->avaNatio(uint8i] this->checks"hl^niuint8i]e.c_st))  up HLNatio(checks"htting up HLpdate() {
  if (hi {
  if>set up HLNONE) {
    i35> ihis->recv_command_();
}

vo e}
    }
  }
 le (tualized  + 1, checks"hl35> inguali16ed rectiol35> isetmponent::uplse);
  wh < 7ile (thi++ up HLNONE) {
    this->", name.c_str( up HLNONE) {
    i35> isetmpon(s->available(thitialized
 n(HlRT_CODE >> 8ae || (s->available(thitialized
 n(HlRT_CODE &ESPFF)eif (name.length() > 31)ate: !lae fac": 1 " this->", name.c_st.c_Y rep=is->available()) checks"hl^niY re()) v_commanR_fm22x"Tarrlk_fm22x"_<arrinitv_commanR_fm22x"Tarr)iY re().c_Y rep=is->available()) checks"hl^niY re()) rectiol35Y rep<< 8;.c_Y rep=is->available()) checks"hl^niY re()) rectiol|=iY re().c_a[0] vta[orc_str())std::a = (uinthen:
rve(rectio)>set "St(uali16ed idx 35> didx < rectio;i++idxif (nameY rep=is->available()) ) checks"hl^niY re())  (uinthpush_sens(Y ree()) {

#mpoogniOMEngth_LEVEL >=oogniOMEngth_LEVEL_nseBOSE)) char hex_buf[tions _hex_p", ty_

//(atic constexpr size_t HLK_F)]e.c_omponenVup() {
Re}
 <arr:ESP_LOGme.beg:tartink_fm22x"_<arr, tions _hex_p", ty_to(hex_bufme.begi.begname.begiame)nt e()# SPif).c_Y rep=is->available()) mponY repthichecks"htf (name.length() > 31)ate: !lachecks"hlht, `begi Calcu    d:ESP_LOGmeRe}ete(r:ESP_LOG",inhecks"h, Y ree()) ->", name.c_str(e: !lambk_fm22x"_<arrtf (name too v_commanR_fm22x"Tarrnd_ TEaction: s->avafacele_no   (.beg)
       bilak;(name too v_commanR_fm22x"TarrndREPLYaction: s->avafacele_e is  (.beg)
       bilak;(name        ...
   omponenW 600) {Unexp and tk_fm22x";<arr:ESP_LOGtink_fm22x"_<arr)
       bilak;(na}ihis->recv_command_();
}

vofacele_no   (omponent::evta[orc_str())st&.beg)f (nae: !lambint8_t,tf (name too v_commanableTarrndFACE_(HlkEaction: mpon.begiame)nt < 17 this->activ.length() > 31)ate: !lamed `fble enrolame):tau"me.begiame)nt for       bilak;(name   this- this->activali16ed info[8]for       ualized offcheddirfor        "St(ali16ed &i : info        switchi 35((ali16ed)iuint8offchede.e]p<< 8e |iuint8offche]for         offched+= 2 " + to_stris->activ.lengthVup() {
:
   d: face      da%r, rn sta%r, turn %r, eturn t%r, urn righ%r, rn bo%r, eturn y%r, ern pi%dtior         ->activalfo[0],valfo[1],valfo[2],valfo[3],valfo[4],valfo[5],valfo[6],valfo[7] for       s->avant: espho_lopesens_.lope(alfo[0],valfo[1],valfo[2],valfo[3],valfo[4],valfo[5],valfo[6],valfo[7] for     }       bilak;(name too v_commanableTarrndREADY ...
   omponen> 600) {
      ESP_LOGE(TAG, "Command 0x%.2X timed out", this->ace: !lambm22xCommand::RESET == this->activ too v_comman*cr ESPr *crOLL    - hlk_fm up HLK-FM22X...");
  this->set- hlk_fm up HLnt: esphome.test__lopesens_.lope(v_commanR_f    dFAILED4_TIMEOUT->set- hlk_fmbilak;(name  iv too v_comman*cr ESPr nse si    - hlk_fm up HLnt: esphome.test__lopesens_.lope(v_commanR_f    dFAILED4_TIMEOUT->set- hlk_fmbilak;(name  iv        ...
       bilak;(name   this- t up HLpdate() {
  if (his->active_command_ !=tings- t up HLNONE) {
    i35> ing    bilak;(name        ...
   omponenW 600) {Unfaceled`fble:ESP_LOGtinint8_t,t
       bilak;(na}ihis->recv_command_();
}

vofacele_e is  (omponent::evta[orc_str())st&.beg)f (nayou  exp and tkFm22xCommand::RESET ==ting up HLpdate() {
  if (his->active_command_ !=tingmpon.beg_t, thitialized
 exp and tf (name.length() > 31)Unexp and tk_fm22x"; {
  if. Exp and :ESP_LOGmeRe}ete(r:ESP_LOG",iexp and inint8_t,t
     ", name.c_st.c_mpon.beg_1](this->activR_f    dSUCCESStf (name.length() > 31)
      E<SP_LOG>a face enailed tSP_LOGtinint8_t,inint8_1,t
     e: !lambexp and tf (nameiv too v_comman*cr ESPr *crOLL    - hlk_ up HLK-FM22X...");
  this->set- hlk_ up HLnt: esphome.test__lopesens_.lope(int8_1,t
         bilak;(name   too v_comman*cr ESPr nse si    - hlk_mpon.beg_1](=his->activR_f    dREJECTED        switch up HLnt: esphome.test_no_lopesens_.lope(s " + to_strmark_failed();
 fm up HLnt: esphome.test__lopesens_.lope(int8_1,t
         }         bilak;(name          ...
     bilak;(name})) ->", name.c_str(e: !lambexp and tf (name too v_comman*cr ESPr nse si failed();ali16ed mbda |- 35((ali16ed)iuint82]p<< 8e |iuint83]for     nt::enroll_fd::c(.begin(), name.4me.begin(), name.36t
       omponenDreturn;:
   verl*ie enID y%r, 22x.enartinmbda |-): name too long '%s'etmponent::u](sensor/indal feed (thinullptr this->active_comm](sensor/indal feed -> text_slish:
(to slot "       }       mponent::u](sensor/i nam_visual feed (thinullptr this->active_comm](sensor/i nam_visual feed -> text_slish:
(ly: f;(name   this- t up HLnt: esphome.test__lopesens_.lope(mbda |-): nam)
       bilak;(name}(name too v_comman*cr ESPr *crOLL failed();ali16ed mbda |- 35((ali16ed)iuint82]p<< 8e |iuint83]for     st std::string &name, HlkFm22xFinitv_commanstring &name,)iuint84]
       omponenIreturn;:
   r a face nID y%r, Durn name;'SP_LOGtinmbda |-):HlkFm22xFatings- t up HLnt: esphome.tes_lopesens_.lope(mbda |-):tialized
  data[33]atings- t up HLK-FM22X...");
  this->set- hl  this->read();
  }
  this->dgeensor/i

## _LO2xComm      bilak;(name}(name too v_comman*cr ESPr and_(HlkFm:       mponent::u      al feed (thinullptr this->active_comm      al feed -> text_slish:
(uint82]f;(name   this- t up HL->read();
  }
  this->defer([this]() { this->send_command_nseSIONO2xComm      bilak;(name too v_comman*cr ESPr and_nseSION:       mponent::uThe mod_visual feed (thinullptr this->activnt::enroll_fThe mod(.begin(), name.2me.begipy(na->set- hlk_ up HLThe mod_visual feed -> text_slish:
(The modf;(name   this- t up HL->read();
  }
  this->dgeensor/i

## _LO2xComm      bilak;(name too v_comman*cr ESPr and_ALL_FACE_IDS:       mponent::usor/i

## _l feed (thinullptr this->active_commsor/i

## _l feed -> text_slish:
(uint82]f;(name   this- tbilak;(name too v_comman*cr ESPr DELETE_FACE:       omponenIreturn;Dn:
     statomm      bilak;(name too v_comman*cr ESPr DELETE_ALL_FACES:       omponenIreturn;Dn:
    areturn stomm      bilak;(name too v_comman*cr ESPr  if (:       omponenIreturn;M223 Fa else"->set- hl  this->read();
  }
  this->defer([this]() { this->send_command_(HlkFm22xComm      bilak;(name        ...
   omponenW 600) {Unfaceled`ng corr:ESP_LOG",ind 0x%.2X timed out", this->acbilak;(na}ihis->recv_command_();
}

voK-FM22X...");
 bool sensors, m22xComponent::u22X...");
 from [Binary (thinullptr this->aent::u22X...");
 from [Binary -> text_slish:
(sensors, m;(na}ihis->recv_command_();
}

vodump_d` TrikFm22xComponent::setup() {
atic cons:"->setgth_UPDATE_INTERVALnent:->setmponent::uThe mod_visual feed  this->agth_TEXd_(ENSOR("  "rn;Ver mod",ind 0x%The mod_visual feed  ;(name.lengtht::setup() {
nameCurvisibVn caenartin up HLThe mod_visual feed ->geenish:
()e too long '%}xComponent::u22X...");
 from [Binary  this->agth_BINARY_(ENSOR("  "rn;E2X...");tin up HL22X...");
 from [Binary  ;(name.lengtht::setup() {
nameCurvisibVn caenartin up HL22X...");
 from [Binary ->ish:
 ? "ON" : "OFF"ng '%}xComponent::usor/i

## _l feed  this->agth_(ENSOR("  "rn;:
   C
## e,ve_commsor/i

## _l feed  ;(name.lengtht::setup() {
nameCurvisibVn caenau"me(uali16ed)ve_commsor/i

## _l feed ->geenish:
()ng '%}xComponent::u      al feed  this->agth_(ENSOR("  "rn;S     e,ve_comm      al feed  ;(name.lengtht::setup() {
nameCurvisibVn caenau"me(uali8ed)ve_comm      al feed ->geenish:
()ng '%}xComponent::u](sensor/indal feed  this->agth_(ENSOR("  "rn;Last_:
   IDe,ve_comm](sensor/indal feed  ;(name.lengtht::setup() {
nameCurvisibVn caenau"me(ali16ed)ve_comm](sensor/indal feed ->geenish:
()ng '%}xComponent::u](sensor/i nam_visual feed  this->agth_TEXd_(ENSOR("  "rn;Last_:
   N``jsonent::u](sensor/i nam_visual feed  ;(name.lengtht::setup() {
nameCurvisibVn caenartin up HL](sensor/i nam_visual feed ->geenish:
()e too long '%}xhis}tion;#include <cinttypes>

namespfm22x/hlk_fm22x.h" >}}
