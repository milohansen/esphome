---
description: "Instructions for setting up the core ESPHome configuration."
title: "ESPHome Core Configuration"
params:
  seo:
    description: Instructions for setting up the core ESPHome configuration.
    image: cloud-circle.svg
---

Here you specify some core information that ESPHome needs to create
firmwares. Most importantly, this is the section of the configuration
where you specify the **name** of the node.

```yaml
# Example configuration entry
esphome:
    name: livingroom
    comment: Living room ESP32 controller
    area: Living Room
```

{{< anchor "esphome-configuration_variables" >}}

## Configuration variables

- **name** (**Required**, string): This is the name of the node. It
  should always be unique in your ESPHome network. May only contain lowercase
  characters, digits and hyphens, and can be at most 24 characters long by default, or 31
  characters long if `name_add_mac_suffix` is `false`.
  See [Changing ESPHome Node Name](#esphome-changing_node_name).

- **friendly_name** (*Optional*, string):
  This name is sent to the frontend and used by Home Assistant as
  the integration and device name. It also gets prefixed to entity
  names when needed. While optional, leaving it out can result in
  less intuitive names and a less polished experience in Home
  Assistant. Setting a `friendly_name` helps keep things clear,
  consistent, and easier to manage.

- **area** (*Optional*, string or [Area Configuration](#esphome-area)): The area configuration for this device. This is sent to
  Home Assistant to specify which area/zone the device belongs to. Can be either a simple string (e.g., `"Living Room"`  )
  or a structured format with `id` and `name`.

Advanced options:

- **build_path** (*Optional*, string): Customize where ESPHome will store the build files
  for your node. By default, ESPHome puts the PlatformIO project it uses to build the
  firmware in the `.esphome/build/<NODE>` (or into path from `ESPHOME_BUILD_PATH` environment variable if specified) directory,
  but you can customize this behavior using this option. Official docker image automatically use `/build` folder
  as default one in case it is mounted to it.

- **platformio_options** (*Optional*, mapping): Additional options to pass over to PlatformIO in the
  platformio.ini file. See [`platformio_options`](#esphome-platformio_options).

- **environment_variables** (*Optional*, mapping): Environment variables to set during the build process.
  See [`environment_variables`](#esphome-environment_variables).

- **includes** (*Optional*, list of files): A list of C/C++ files to include in the (auto-generated) `main` file.
  The paths in this list are relative to the directory where the YAML configuration file is located or `<...>` includes.
  See [`includes`](#esphome-includes).

- **includes_c** (*Optional*, list of files): The same as `includes` but for files that require C linkage. All includes
  will be wrapped in `extern "C" {}`. See [`includes`](#esphome-includes).

- **libraries** (*Optional*, list of libraries): A list of libraries to include in the project. See
  [`libraries`](#esphome-libraries).

- **comment** (*Optional*, string): Additional text information about this node. Only for display in UI.
- **name_add_mac_suffix** (*Optional*, boolean): Appends the last 3 bytes of the mac address of the device to
  the name in the form `<name>-aabbcc`. Defaults to `false`.
  See [Adding the MAC address as a suffix to the device name](#esphome-mac_suffix).

- **project** (*Optional*): ESPHome Creator's Project information. See [Project information](#esphome-creators_project).

  - **name** (**Required**, string): Name of the project
  - **version** (**Required**, string): Version of the project
  - **on_update** (*Optional*, [Automation](/automations)): An automation to perform when the device firmware is updated.
    This compares the above `version` field with the `version` that was in the previous firmware
    as long as the `name` matches.
    The `version` is stored in flash memory when the firmware is first run for future comparisons.

- **min_version** (*Optional*, string): The minimum ESPHome version required to compile this configuration.
  See [Minimum ESPHome version](#esphome-min_version).

- **compile_process_limit** (*Optional*, int): The maximum number of simultaneous compile processes to run.
  Defaults to the number of cores of the CPU which is also the maximum you can set.

- **debug_scheduler** (*Optional*, boolean): If set, the scheduler will print debug information about scheduled tasks at log level DEBUG.
- **areas** (*Optional*, list of [Area Configuration](#esphome-area)): Additional areas that can be referenced by devices.
- **devices** (*Optional*, list of [Sub-Devices](#esphome-devices)): Sub-devices to group entities under.

Automations:

- **on_boot** (*Optional*, [Automation](/automations)): An automation to perform
  when the node starts. See [`on_boot`](#esphome-on_boot).

- **on_shutdown** (*Optional*, [Automation](/automations)): An automation to perform
  right before the node shuts down. See [`on_shutdown`](#esphome-on_shutdown).

- **on_loop** (*Optional*, [Automation](/automations)): An automation to perform
  on each `loop()` iteration. See [`on_loop`](#esphome-on_loop).

{{< anchor "esphome-on_boot" >}}

## `on_boot`

This automation will be triggered when the ESP boots up. By default, it is executed after everything else
is already set up. You can however change this using the `priority` parameter.

```yaml
esphome:
  # ...
  on_boot:
    - priority: 600
      then:
        - switch.turn_off: switch_1
```

### Configuration variables

- **priority** (*Optional*, float): The priority to execute your custom initialization code. A higher value
  means a high priority and thus also your code being executed earlier. Please note this is an ESPHome-internal
  value and any change will not be marked as a breaking change. Defaults to `600`. Priorities (you can use any value between them too):

  - `800.0`  : This is where all hardware initialization of vital components is executed. For example setting switches
    to their initial state.

  - `600.0`  : This is where most sensors are set up.
  - `250.0`  : At this priority, WiFi is initialized.
  - `200.0`  : Network connections like MQTT/native API are set up at this priority.
  - `-100.0`  : At this priority, pretty much everything should already be initialized.

- See [Automation](/automations).

{{< anchor "esphome-on_shutdown" >}}

## `on_shutdown`

This automation will be triggered when the ESP is about to shut down. Shutting down is usually caused by
too many WiFi/MQTT connection attempts, Over-The-Air updates being applied or through the {{< docref "deep_sleep/" >}}.

> [!NOTE]
> It's not guaranteed that all components are in a connected state when this automation is triggered. For
> example, the MQTT client may have already disconnected. For use-cases that require specific shutdown ordering, look at the `priority` parameter.

```yaml
esphome:
  # ...
  on_shutdown:
    - priority: 700
      then:
        - switch.turn_off: switch_1
```

### Configuration variables

- **priority** (*Optional*, float): The priority to execute your custom shutdown code. A higher value
  means a high priority and in case of shutdown triggers that the code is executed **later**.
  Priority is used primarily for the initialization order of components. Shutdowns for these components are handled in *reverse* order, such that e.g. sensors (600) are shutdown before the hardware components (800) they depend on.
  Please note this is an ESPHome-internal value and any change will not be marked as a breaking change.
  Defaults to `600`. For priority values refer to the list in the [`on_boot`](#esphome-on_boot) section.

- See [Automation](/automations).

{{< anchor "esphome-on_loop" >}}

## `on_loop`

This automation will be triggered on every `loop()` iteration (usually around every 16 milliseconds).

```yaml
esphome:
  # ...
  on_loop:
    then:
      # do something
```

{{< anchor "esphome-platformio_options" >}}

## `platformio_options`

PlatformIO supports a number of options in its `platformio.ini` file. With the `platformio_options`
parameter you can tell ESPHome what options to pass into the `env` section of the PlatformIO file
(note you can also do this by editing the `platformio.ini` file manually).

You can view a full list of PlatformIO options here: <https://docs.platformio.org/en/latest/projectconf/section_env.html>

```yaml
# Example configuration entry
esphome:
  # ...
  platformio_options:
    upload_speed: 115200
    board_build.f_flash: 80000000L
```

{{< anchor "esphome-environment_variables" >}}

## `environment_variables`

With the `environment_variables` option, you can set environment variables that will be available during the
compilation process. This is useful when you need to pass configuration to build scripts, custom libraries,
or PlatformIO build environments.

```yaml
# Example configuration entry
esphome:
  # ...
  environment_variables:
    HTTP_PROXY: "http://user:pass@10.10.1.10:3128/"
    PLATFORMIO_SETTING_ENABLE_PROXY_STRICT_SSL: "false"
```

> [!NOTE]
> Environment variables set here are only available during the build process. They do not affect
> the runtime behavior of your device.

{{< anchor "esphome-includes" >}}

## `includes`

With `includes` you can include source files in the generated PlatformIO project.
All files declared with this option are copied to the project each time it is compiled.

You can always look at the generated PlatformIO project (`.esphome/build/<NODE>`  ) to see what
is happening - and if you want you can even copy the include files directly into the `src/` folder.
The `includes` option is only a helper option that does that for you.

```yaml
# Example configuration entry
esphome:
  # ...
  includes:
    - my_switch.h
    - <mylib.h>
```

This option behaves differently depending on what the included file is pointing at:

- If the include string is written <nam    ated or `<."  ated "`,he listn`in#clude st  ated ori    tadd to the prbeginng -  the Plain` .cppfile.
   If the include string is wrinting at:
 herectory,
 he intitirdirectory whtrees comped toto the `   tc/` older.
Th If the include string isintinto pahelpar ofle is(.h, .hpp, .tcc),t is comped totohe sch/` older.
   tANDncluded fi the `.ein` .cppfile.
 his isys he lastmbdaode isn alwccs inttTh If the include string isintinto pahereguredource files s(.c, .cpp),t is comped totohe sch/` older.
   tANDnmpiled.
nto the `sbinary his isys hple snt vion of viarees tod iffuncons in itlpar ofle issn a   tbprojevid.

Yo< anchor "esphome-inbraries,
>}}

## `inbraries`](
he `inbraries`](ption arellowsou ca include inbraries totohe scatformIO project.
Ahey sinbraries toll been:
tbp
mpiled.
nto the `ssult ig isrmware isd ify ha unid by Ho[stmbdas/automations)./mptstest/#nfigur-stmbda)
```yaml
# Example configuration entry
esphome:
  # ...
  inbraries t    - # lesrarieyrom `EatformIO p   - <mphoss aif/pho32-cetera
   - # lesrarieyrbuled inth thArduino   - <mWect
   - # e ane gen isvsion of thlesrarieyrid by Hoaomponents    - <mImojev=tps://don ihub.mpo/imojev-wifi/sdk-cpp.n i#v1.0.0``

Thismost semmenouse e au the  option beito include ine  rd-ram vabraries to t allravailable du the [`oatformIO prregt ory](tps://doatformio.org/enbra)They don be at dd tobyist og the birame inder.
his option. OfIts also thpo aie du inid 
ecific shvsion osor 31 infeh.habraries toom `Eailes s 31n isrepo iry w.SPHome whwccsp the Plme assy vixs the `
[bra_pens](tps://docs.platformio.org/en/latest/projectconf/section_esn/lv/tions:
/srariey/bra_penstml>
)ption. O

Ung thname>-a=<urce f orsy vix,t is copo aie du iner tridane gevsion ofid byr yobraries to t allravaomatically us dd t
byne in thPHome w'somponents. Shis com be ateful whring thdel Dopmt to thmakESPHome wie anyustom lifk co thlesrarieyO

 default, ESPHome pues tht afclude iny chbraries toto the project eShis coans a  t albraries to t allravbuled inth t
Arduinosuch tham  Wector `<.EEOXYM`,hlran'tvailable d.f thu need to pae ane gmyou caould alst ofem tonually).nder.

is option. OfIfhey delravid by Hoat ar vasrariey,hey deould alblist i by ore the hasrarieyr t ales to m t
Yo< anchor "espferenced s-ash: _ittee_ternaval>}}

## `iPferenced s Cponents  
is comparents s used pr seere thdatan the forsh memory whenh is alpsion i byacro aevice fireots u,.g. see lastst/p
ate wh thlesrt be the inwccumuled Pleratgyrid by Hoanppliedced 
```yaml
# Example configuration entry
espferenced s    ash: _ittee_ternaval115min``

### Configuration variables

- **prash: _ittee_ternaval (*Optional*, [AuTi](#e/guidas/nfiguration e-typt/#me i) Customize whe fronequcedin UIenh isdatan   forlued ex the frosh: Shis cotting swlps ke pasverss srapidhange.
to pahemparents som `Eing apquickl  naitten <n the frosh: sd ifwearg it out cDefaults to `605min See to th`nery `o thdisle duis opfeare c
Autsll covices tove alr mit** exmber of oposh: sittee cycs

this istting swlps ke pad wucehe number of coosh: sittees
dudu inquickl  anging_nomponents. ShIthe preas ESen yomponents (8ch tham  srt b`,h`itch.h`,h`fanand `naglobso `
we arange.
dthe schte whe in mmedie w contmmten ex thosh: Shis`ssult iu the  opwathat the cost 3 ate wh these c
mponents (8wld always besulre theots `pst 3 ate wh nopow vaso a,owever cthis ish the `nco of Plpont, ily).nquickl  damagg the buosh: sifhese components are haquickl  angin.

YoAlmefehypfeare csh the ubein yople snt v ex thmteige whisss refelt ig isrm `Ee hasrt** exmber of oposh: sittee cycs

t
e schte wh first ruored in flmory wh ore thing aprlued ex thosh: sder eve `.eash: _ittee_ternaval`sh thss@1. Fois c
felt itotohfew vaosh: sitteesprettsnavg the buosh: slpalth. 
is cohavior ofm be atmodied) y Hotting sweash: _ittee_ternaval`s th`0s`o compit**he `ncnge.
to paosh: sd(8coo<nam po aie d,
wever cth at re isat the  coa halparo incluas t byrsh: siearg itd a leoulrnt,edevice nalifphoan!

r pr< docref "de/mponents a/pho8266"ESPHo8266"E}

,h`sulre t_rm `lash: ` musalso gebset up th`true`or settes betoe wrapten <n thosh: S{{< anchor "esphome-connging_node_name).>}}

## Connging ESPHome Node Name]( 
iryg theohange thisname of thaode sh int areress as the fotwork. ?ou can al someith the `veid _eress a(ption ar the Pl< docref "dewifi"ESFi isnfiguration e>}}.

> Cnge thisnavice name](r a sress as thur deML co the numewalue and anyitional al  t upeid _eress a(p pasntino the nuold sress aske MQso:```yaml
# ExStep 1.onnging ESme](rrm `Eeulr8266o thkches
nsphome:
  # me: likches
ns# ...
  
wifi  # ...
  inid _eress a:Eeulr8266.catel``

##Nowpload_she nudated.
snfiguro the device n. Aa sufonds)ettepyou canowped to paroryvthisn
eid _eress a(ption arrm `Eur codeiguration vaagn lo the  thsubsequcetpload_stoll berk coagn l
( ar vwi it isll beerto exload_shethe nuold sress a)
```yaml
# ExStep 2sphome:
  # me: likches
ns# ...
  
wifi  # ...
  in# Roryvth ofmment**ut caid _eress a
- # e a_eress a:Eeulr8266.catel``

##T Plme asocessde com be atde inr seanging_noe schte  shIPf thaovice.

{{< anchor "esphome-inc_suffix).>}}

## Coding the MAC address as a suffix to the device name](

Ung thnme_add_mac_suffix` isellowso< docref "de/guidas/nators_p"ESnators_p"E}

o
  ojevion ofltanie covices to the cofaory wheh thsimpnglesrmware isd if ogll
ve alique in dt, ic sion for thstom l imanhtells.> [!NOTE]
> Enviused rtoll beed to paeate
f  incldividllyAML configurile is fhey dewt to spOTAudated.hisn
>ovices to the forure c.reator'scom befaoilita this isocess. y Hoojevidg thndh: ard_buportan` URL
>or theiused rtShis coellowsoem too)asier).ndated.hisnirovices to sumewafeare care hamadavailable d
>oupstatot
Yo< anchor "esphome-creators_project).>}}

## `iPfect information](This autllowsoeators_po pahddhe project eame](rd ifvsion of the dempiled.
nce. It
 s comurntly dely a
expo .
nviaEe hasoered, mDNSnd thuscovices _formefelnen itviaEe hative API aShis`srmat wi the node](
ould albli`autr "ame)..oject e_me`.

Ad`yaml
# Example configuration esphome:
  # .
  plaject e    name: li"jses .d.
proam v    PLvsion oli"1.0.0"``

{{< anchor "esphome-enn_version).>}}

## `inimum ESPHome version](This autllowsoML coles to inecify the **nimum ESvsion of thPHome vequired to compile t.
is is useful wh the fose of shpacge. where all pubshed expacge. *nit bee anfeare carly a
ailable du thaumew valsion of thPHome vShis coellowsof a stme thiendly_n err a msese.

- `yaml
# Example configuration esphome:
  # n_version).: 2025.11.0``

Th< anchor "esphome-eneas >}}

## Coda Configuration](YoAas thlps h ogane whur device.
sn Home
 ssistant tobyisocion. SePHome vepports a orksrmat wsof a sa configuration f:``**Sple stSing isFmat w:**```yaml
esphome:
  # me: limyevices 
area: Liiving Room"` ``

Th**Suctured foFmat w:**```yaml
esphome:
  # me: limyevices 
area: L   imadlivingro_om
    come: li"ving Room"` ``

ThT Plmple string (ermat wi confivennt maf a biercee anses there you spjusalwt to sps@1igthe ESP isvice to
 aherm"`The `iructured format wiirefemment*d when thing ths-devices t,o suitrellowsou ca inferenced reas thbyhisniroID
> Cfiguration variables

 (ructured format w)
- **onid (**Required**, string): VeUque in dt, ic  vao the inwas . **name** (**Required**, string): ThDplay inme](rr the inwas . h< anchor "esphome-envices t>}}

## Cob-Devices](

PHome vepports a eatorg ths-devices theh t thaumpnglesP isntroller
 Shis coellowsou ca inoup entities u
to thsoeallyevice.
sn t allppeedouerame w co Home
 ssistant tThis is usoam icured use `l when y
- **OnesP isaoras a suhub/ge wys hr thltanie cophysallyevice.
sn(RF bridg t,oModbuaevice fu,.gtc.) **AumpnglesP isntrolleshltanie cone tsh ofrm"`s **Y want yobtin of ogane ion of vitities un Home
 ssistant t### Configuration variables

- **prid (**Required**, string): VeUque in dt, ic  vao the invice.

{**name** (**Required**, string): ThDplay inme](rr the invice.

{**nawas _id (**Rtional*, string): ThRerenced r
 ahn sa coIDefauin in `exeas t

Ad# Coample cThRF Bridg  Ge wys - `yaml
# Exa32 coaori as thRF bridg hr thltanie co433MHzevice fusphome:
  # me: lirf-bridg 
area: LiiUtilityoom"` - # Sple string (ermat wir thP isvice t'are ha
   vice fu    - myadlionten_do "avices 
ar  come: li"Fnten Do " Ssors "
ar  cowas _id:ntry
ced _e ha
  - myadlikches
n_moon_envices 
ar  come: li"Kches
noMoon e>
ar  cowas _id:nkches
n_e ha
  - myadligamege_do "avices 
ar  come: li"Gamege Do ">
ar  cowas _id:ngamege_e ha
   eas t    - myadlitry
ced _e ha
  - come: li"Ery
ced "
  - myadlikches
n_e ha
  - come: li"Kches
n"
  - myadligamege_e ha
  - come: li"Gamege"
 Exah tiRF vice tolppeedas a suferame w vice to HomA
binary_nsors : - `-atformio:aroryte_femee Ar   come: li"Fnten Do ""
  - vices _fdlionten_do "avices 
ar  rcwitch.h_raw      # ce. : '101010110101'
 - `-atformio:aroryte_femee Ar   come: li"Kches
noMoon e>
ar  vices _fdlikches
n_moon_envices 
ar  rcwitch.h_raw      # ce. : '110011001100'``

### Coample cThMtani-Ze inCtroller
  ``yaml
esphome:
  # me: limtani-rm"`-ntroller
     vice fu    - myadlivingro_om
 avices 
ar  come: li"ving Room"`nCtroller
 >
ar  cowas _id:nvingro_e ha
  - myadlikches
n_vices 
ar  come: li"Kches
noCtroller
 >
ar  cowas _id:nkches
n_e ha
   eas t    - myadlivingro_e ha
  - come: li"ving Room"` `  - myadlikches
n_e ha
  - come: li"Kches
n"

nsors : - `-atformio:adh    - pi.: GPIO5   theempateded :
  - come: li"Tempateded >
ar  covices _fdlivingro_om
 avices 
ar  humidgty:
  - come: li"Humidgty>
ar  covices _fdlivingro_om
 avices 
`

### ee [AAls