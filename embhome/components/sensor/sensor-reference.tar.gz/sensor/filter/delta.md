---
description: ""
headless: true
---

This filter stores the last value passed through this filter and only passes incoming values through
if incoming value is sufficiently different from the previously passed one.
This difference can be calculated in two ways an absolute difference or a percentage difference, and
with respect to a minimum, `min_value` and maximum value, `max_value`.

## Configuration variables

- **min_value** (*Optional*, float, percent): The minimum absolute or percentage difference required (default is `0.0`)
- **max_value** (*Optional*, float, percent): The maximum absolute or percentage difference allowed (default is infinity)
- **baseline** (*Optional*, float, [lambda](/automations/templates#config-lambda)): A baseline to use
  when calculating the difference. By default the last passed value is used.

At least one of `min_value` or `max_value` must be specified. Alternatively to specifying `min_value`
and/or `max_value` as keys, you can also just provide a single float or percentage value. In this case the value
is interpreted as `min_value`.

The filter will reject values that do not differ from the baseline by more than `min_value`, or that
differ from the baseline by more than the `max_value`.
For example, if the filter were configured with a value of `2.0` only values that differ from the last
passed value by more than `2.0` will be passed through.

> [!NOTE]
> A `min_value` of `0.0` means that
> values equal to the last value will not be passed through, only values that differ, making it useful for
> eliminating duplicate values.

```yaml
# Example configuration entry
filters:
  - delta:
      min_value: 2.0
    # Same as above, min_value is implied here.
  - delta: 2.0

  - delta:
      max_value: 10%
    # Specifying both min_value and max_value is permitted.
  - delta:
      min_value: 2.0
      max_value: 10%
```

If a percentage is specified a percentage of the last value will be used as the required difference.
For example if the filter were configured with a value of 20% and the last value passed through was 10,
only values greater than or equal to 12 or less than or equal to 8 would be passed through.
However, if the last value passed through was 100 only values greater than or equal to 120 or less than or
equal to 80 would be passed through.

```yaml
# Example configuration entry
filters:
  - delta: 20%
```

When setting a maximum delta filter, it may be possible for the sensor values to escape the
bandwidth permitted by the filter without returning. In this case, it can be helpful to override the
value being compared from the default of the last value to an arbitrary other sensor that determines
a baseline:

```yaml
# Example configuration entry
sensors:
    # This sensor just calculates the baseline.
  - platform: copy
    source_id: my_sensor_to_be_filtered
    id: baseline
    filters:
      - median:
          window_size: 6
          send_every: 1
          send_first_at: 1

    # This sensor will publish the values from your sensor with the max delta filter applied.
  - platform: copy
    source_id: my_sensor_to_be_filtered
    name: "Filter Max With Baseline"
    id: filter_baseline_max
    filters:
      - delta:
          max_value: 10
          baseline: !lambda return id(baseline).state;
```
